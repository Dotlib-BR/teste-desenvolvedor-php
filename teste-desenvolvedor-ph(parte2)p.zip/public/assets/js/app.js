function transferirValor() {
    jQuery('#username').val(jQuery('#email').val());
}
