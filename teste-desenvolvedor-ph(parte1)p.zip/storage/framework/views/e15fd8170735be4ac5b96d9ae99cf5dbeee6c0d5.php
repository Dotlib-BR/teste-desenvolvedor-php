<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Google Font: Source Sans Pro -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
        <!-- Font Awesome -->
        
        <link href="<?php echo url('assets/plugins/fontawesome-free/css/all.min.css'); ?>" rel="stylesheet">
        <!-- icheck bootstrap -->
        
        <link href="<?php echo url('assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css'); ?>" rel="stylesheet">
        <!-- Theme style -->
        
        <link href="<?php echo url('assets/css/adminlte.min.css'); ?>" rel="stylesheet">

    </head>
    <body class="hold-transition login-page">

        <?php echo $__env->yieldContent('content'); ?>

        <!-- jQuery -->
        
        <script src="<?php echo url('assets/plugins/jquery/jquery.min.js'); ?>"></script>
        <!-- Bootstrap 4 -->
        
        <script src="<?php echo url('assets/plugins/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
        <!-- AdminLTE App -->
        
        <script src="<?php echo url('assets/js/adminlte.min.js'); ?>"></script>
        <!-- Scripts do App -->
        <script src="<?php echo url('assets/js/app.js'); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/layouts/auth-master.blade.php ENDPATH**/ ?>