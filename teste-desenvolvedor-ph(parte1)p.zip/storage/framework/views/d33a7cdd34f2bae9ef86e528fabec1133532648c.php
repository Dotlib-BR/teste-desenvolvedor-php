<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Vagas de Emprego</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Vagas de Emprego</li>
                    </ol>
                </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="bg-light p-4 rounded">
                    <div class="lead">
                        Editar vaga de emprego <b>"<?php echo e(ucfirst($post->title)); ?>"</b>.
                    </div>

                    <div class="container mt-4">

                        <form method="POST" action="<?php echo e(route('posts.update', $post->id)); ?>">
                            <?php echo method_field('patch'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input value="<?php echo e($post->title); ?>"
                                    type="text"
                                    class="form-control"
                                    name="title"
                                    placeholder="Title" required>

                                <?php if($errors->has('title')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('title')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <input value="<?php echo e($post->description); ?>"
                                    type="text"
                                    class="form-control"
                                    name="description"
                                    placeholder="Description" required>

                                <?php if($errors->has('description')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="body" class="form-label">Body</label>
                                <textarea
                                    type="text"
                                    class="form-control"
                                    name="body" rows="8"
                                    placeholder="Body" required><?php echo e($post->body); ?></textarea>

                                <?php if($errors->has('body')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('body')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="type" class="form-label">Tipo de Contratação</label>
                                </br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="type" id="inlineRadio1" value="CLT" 
                                    <?php if($post->type == 'CLT'): ?> checked <?php endif; ?>/>
                                    <label class="form-check-label" for="inlineRadio1">CLT</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="type" id="inlineRadio2" value="Pessoa Jurídica" 
                                    <?php if($post->type == 'Pessoa Jurídica'): ?> checked <?php endif; ?>/>
                                    <label class="form-check-label" for="inlineRadio2">Pessoa Jurídica</label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="type" id="inlineRadio3" value="Freelancer" 
                                    <?php if($post->type == 'Freelancer'): ?> checked <?php endif; ?>/>
                                    <label class="form-check-label" for="inlineRadio3">Freelancer</label>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-default">Voltar</a>
                        </form>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/posts/edit.blade.php ENDPATH**/ ?>