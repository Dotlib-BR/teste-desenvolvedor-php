<?php $__env->startSection('content'); ?>
    <div class="register-box">
        <div class="card card-outline card-primary">
          <div class="card-header text-center">
            <label class="h1"><b><?php echo e(config('app.name', 'Laravel')); ?></b></label>
          </div>
          <div class="card-body">
            <p class="login-box-msg">Registrar Usuário</p>

            <form method="post" action="<?php echo e(route('register.perform')); ?>">
                <?php echo csrf_field(); ?>

                <div class="input-group mb-3">
                    <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" placeholder="Nome Completo" required="required" autofocus>
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-user"></span>
                        </div>
                    </div>
                    <?php if($errors->has('name')): ?>
                        <span class="text-danger text-left"><?php echo e($errors->first('name')); ?>&emsp;&emsp;&emsp;</span>
                    <?php endif; ?>
                </div>

                <div class="input-group mb-3">
                    <input type="email" class="form-control" name="email"  id="email" value="<?php echo e(old('email')); ?>"
                    onkeyup="transferirValor();" placeholder="E-mail" required="required" autofocus>
                    <input type="hidden" name="username" id="username">
                    <input type="hidden" name="token"  value="<?php echo e(csrf_token()); ?>" />
                    <input type="hidden" name="level"  value="0" />
                    <input type="hidden" name="status" value="0" />
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <br><span class="text-danger text-left"><?php echo e($errors->first('email')); ?>&emsp;&emsp;&emsp;</span>
                    <?php endif; ?>
                </div>

              <div class="input-group mb-3">
                <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Senha" required="required">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-lock"></span>
                  </div>
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('password')); ?>&emsp;</span>
                <?php endif; ?>
              </div>
              <div class="input-group mb-3">
                <input type="password" class="form-control" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="Confirmar Senha" required="required">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-lock"></span>
                  </div>
                </div>
                <?php if($errors->has('password_confirmation')): ?>
                    <span class="text-danger text-left"><?php echo e($errors->first('password_confirmation')); ?>&emsp;</span>
                <?php endif; ?>
              </div>
              <div class="row">
                <div class="col-8">
                  <div class="icheck-primary">
                    <input type="checkbox" id="agreeTerms" name="terms" value="agree" required="required" >
                    <label for="agreeTerms">
                     Concordo com os <a href="#">termos</a>
                    </label>
                  </div>
                </div>
                <!-- /.col -->
                <div class="col-4">
                  <button type="submit" class="btn btn-primary btn-block">Confirmar</button>
                </div>
                <!-- /.col -->
              </div>

              <p class="mb-0">
                <a href="<?php echo e(route('login.perform')); ?>" class="text-center"><strong>Login</strong></a>
              </p>
              <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <!-- /.register-box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/auth/register.blade.php ENDPATH**/ ?>