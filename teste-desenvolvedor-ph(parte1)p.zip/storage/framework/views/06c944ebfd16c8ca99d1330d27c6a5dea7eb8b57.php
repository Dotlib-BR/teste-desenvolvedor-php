<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Usuários</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Usuários</li>
                    </ol>
                </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="bg-light p-4 rounded">
                    <div class="lead">
                        Editar e gerenciar as permissões para o usuário <b>"<?php echo e(ucfirst($user->name)); ?>"</b>.
                    </div>

                    <div class="container mt-4">

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> Houveram alguns problemas com sua solicitação.<br><br>
                                <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>"> 
                            <?php echo method_field('patch'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input value="<?php echo e($user->name); ?>"
                                    type="text"
                                    class="form-control"
                                    name="name"
                                    placeholder="Name" required>

                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input value="<?php echo e($user->email); ?>"
                                    type="email"
                                    class="form-control"
                                    name="email"
                                    placeholder="Email address" required>
                                <?php if($errors->has('email')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input value="<?php echo e($user->username); ?>"
                                    type="text"
                                    class="form-control"
                                    name="username"
                                    placeholder="Username" required>
                                <?php if($errors->has('username')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-control"
                                    name="role" required>
                                    <option value="">Selecione a regra</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>"
                                            <?php echo e(in_array($role->name, $userRole)
                                                ? 'selected'
                                                : ''); ?>><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('role')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('role')); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3 form-check form-switch">
                                <label for="role" class="form-label">Status:</label>&emsp;&emsp;
                                <input id="status" type="hidden" name="status" 
                                    value="<?php if(!empty($record->status)): ?> 1 <?php else: ?> 0 <?php endif; ?>">
                                <input class="form-check-input" type="checkbox"  [(ngModel)]="rememberMe"
                                    id="flexSwitchCheckDefault" <?php echo e(($user->status == 1 ? 'checked' : '')); ?> 
                                    onclick="document.getElementById('status').value=this.checked?1:0">
                                    <span class="label-text">(Ativar/Desativar)</span> 
                                <?php if($errors->has('status')): ?>
                                    <span class="text-danger text-left"><?php echo e($errors->first('status')); ?></span>
                                <?php endif; ?>
                            </div>

                            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Voltar</button></a>
                        </form>
                    </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('[name="all_permission"]').on('click', function() {
                if($(this).is(':checked')) {
                    $.each($('.permission'), function() {
                        $(this).prop('checked',true);
                    });
                } else {
                    $.each($('.permission'), function() {
                        $(this).prop('checked',false);
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/users/edit.blade.php ENDPATH**/ ?>