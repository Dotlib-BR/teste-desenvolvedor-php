<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Vagas de Emprego</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Vagas de Emprego</li>
                    </ol>
                </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="bg-light p-4 rounded">
                    <div class="container mt-4">
                    <div>
                        <b>Título da Vaga:</b>  <?php echo e($post->title); ?> 
                    </div>
                    <div>
                        <b>Descrição da Vaga:</b>  <?php echo e($post->description); ?>

                    </div>
                    <div>
                        <b>Informações da Vaga:</b>  <?php echo e($post->body); ?>

                    </div>
                    <div>
                        <b>Tipo de Contratação:</b>  <?php echo e($post->type); ?>

                    </div>
                </div>


                <div class="mt-4">
                    <form method="POST" action="<?php echo e(route('posts.apply')); ?>">
                    <?php echo csrf_field(); ?>
                        <input value="<?php echo e(Auth::user()->id); ?>" type="hidden" name="userid"/>
                        <input value="<?php echo e($post->id); ?>" type="hidden" name="postid"/>
                        <button type="submit" class="btn btn-primary">Candidatar à Vaga</button>
                    </form>
                    <br>
                    <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-info">Editar</a>
                    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-default">Voltar</a>

                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/posts/show.blade.php ENDPATH**/ ?>