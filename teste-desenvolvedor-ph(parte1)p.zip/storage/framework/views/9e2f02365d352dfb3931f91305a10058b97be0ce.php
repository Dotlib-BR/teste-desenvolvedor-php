<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Regras</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Regras</li>
                    </ol>
                </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="bg-light p-4 rounded">
                    <div class="lead">
                        Gerenciador de Regras
                        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-sm float-right">Adicionar Regra</a>
                    </div>

                    <div class="mt-2">
                        <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <table class="table table-bordered table-striped">
                    <tr>
                        <th width="1%">Nº</th>
                        <th>Nome</th>
                        <th width="3%" colspan="3" style="text-align:center">Ação</th>
                    </tr>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($role->id); ?></td>
                            <td><?php echo e($role->name); ?></td>
                            <td>
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('roles.show', $role->id)); ?>">Mostrar</a>
                            </td>
                            <td>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('roles.edit', $role->id)); ?>">Editar</a>
                            </td>
                            <td>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                                <?php echo Form::submit('Excluir', ['class' => 'btn btn-danger btn-sm']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <div class="d-flex">
                        <?php echo $roles->links(); ?>

                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/roles/index.blade.php ENDPATH**/ ?>