<p class="mt-2 mb-2 text-muted">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/auth/partials/copy.blade.php ENDPATH**/ ?>