<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Vagas de Emprego</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active">Vagas de Emprego</li>
                    </ol>
                </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="bg-light p-4 rounded">
                    <div class="lead">
                        Gerenciador de Vagas de Emprego
                        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary btn-sm float-right">Adicionar Vaga</a>
                    </div>

                    <div class="mt-2">
                        <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>


                    <table class="table table-bordered table-striped" id="vacancies">
                        <tr>
                            <th scope="col" width="1%">Nº</th> 
                            <th scope="col" width="5%">Título</th>
                            <th scope="col" width="5%">Descrição</th>
                            <th scope="col" width="1%">Tipo</th>
                            <th scope="col" width="1%">Status</th>
                            <th scope="col" width="1%" colspan="3" style="text-align:center">Ação</th>
                        </tr>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($post->id); ?></td>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->description); ?></td>
                            <td><?php echo e($post->type); ?></td>
                            <td style="text-align:center"><?php if($post->status == 1): ?> <b style="color:green">ATIVA</b>
                                <?php elseif($post->status == 2): ?> echo <b style="color:brown">PAUSADA</b>
                                <?php elseif($post->status == 3): ?> echo <b style="color:red">CANCELADA</b>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('posts.show', $post->id)); ?>">Mostrar</a>
                            </td>
                            <td>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('posts.edit', $post->id)); ?>">Editar</a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['posts.destroy', $post->id],'style'=>'display:inline']); ?>

                                <?php echo Form::submit('Deletar', ['class' => 'btn btn-danger btn-sm']); ?>

                                <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                    <div class="d-flex">
                        <?php echo $posts->links(); ?>

                    </div>

                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\teste-desenvolvedor-php\resources\views/posts/index.blade.php ENDPATH**/ ?>