<?php $__env->startSection('content'); ?>
<div class="register-box">
    <!-- /.login-logo -->
    <div class="card card-outline card-primary">
        <div class="card-header text-center">
            <label class="h1"><b><?php echo e(config('app.name', 'Laravel')); ?></b></label>
        </div>
        <div class="card-body">
            <p class="login-box-msg">Efetue o login para iniciar:</p>

            <form method="post" action="<?php echo e(route('login.perform')); ?>">
                <?php echo csrf_field(); ?>

                <div class="input-group mb-3">
                    
                    <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="E-mail" required="required" autofocus>
                    <div class="input-group-append">
                        <div class="input-group-text">
                        <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Senha" required="required">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-8">
                        <div class="icheck-primary">
                        <input type="checkbox" id="remember" >
                        <label for="remember">
                            Lembrar-me
                        </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">Login</button>
                    </div>
                <!-- /.col -->
                </div>

                <?php if(Session::has('message')): ?>
                    <p> </p>
                    <div class="alert alert-success" role="alert" style="text-align:center">
                        <strong><?php echo e(Session::get('message')); ?></strong>
                    </div>
                <?php endif; ?>

                <?php if(Session::has('errors')): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p> </p>
                        <div class="alert alert-danger" role="alert" style="text-align:center">
                            <strong><?php echo e($error); ?></strong>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </form>

            

                
                <!-- /.social-auth-links -->
                <p> </p>
                <p class="mb-1">
                    <a href="<?php echo e(route('forget.show')); ?>"><strong>Esqueceu a senha?</strong></a>
                </p>
                <p class="mb-0">
                    <a href="<?php echo e(route('register.perform')); ?>" class="text-center"><strong>Registrar</strong></a>
                </p>
                <?php echo $__env->make('auth.partials.copy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
    <!-- /.login-box -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/auth/login.blade.php ENDPATH**/ ?>